var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('angular2/core');
var router_1 = require('angular2/router');
var contact_1 = require('../../services/contact');
var base_http_1 = require('../../services/base-http');
var ContactListCmp = (function () {
    function ContactListCmp(contactService, router) {
        this.contactService = contactService;
        this.router = router;
        this.contacts = [];
        this.shadowImage = 'https://image.freepik.com/free-icon/male-user-shadow_318-34042.png';
        this.getList();
    }
    ContactListCmp.prototype.ngOnInit = function () {
        console.log('Init called for contacts');
    };
    ContactListCmp.prototype.getList = function () {
        var self = this;
        var params = {};
        this.contactService.query(params)
            .subscribe(function (contacts) {
            self.contacts = contacts;
        });
    };
    ContactListCmp.prototype.show = function (contactId) {
        this.router.navigate(['/Contact', { id: contactId }]);
    };
    ContactListCmp = __decorate([
        core_1.Component({
            selector: 'contact-list',
            template: "\n    <div class=\"panel panel-default\">\n      \t<div class=\"panel-heading\">\n        \t<h3 class=\"text-center\">\n        \t\tContacts\n        \t\t<a class=\"fa fa-plus btn btn-primary pull-right\" [routerLink]=\"['/NewContact']\"></a>\n        \t</h3>\n      \t</div>\n      \t<div class=\"panel-body\">\n        \t<table class=\"table table-hover\">\n    \t\t\t<thead>\n    \t\t\t\t<tr>\n    \t\t\t\t\t<th>\n    \t\t\t\t\t</th>\n    \t\t\t\t\t<th>\n    \t\t\t\t\t\tName\n    \t\t\t\t\t</th>\n    \t\t\t\t</tr>\n    \t\t\t</thead>\n\n    \t\t\t<tbody>\n    \t\t\t\t<tr *ngFor=\"#contact of contacts\" (click)=\"show(contact.id)\">\n    \t\t\t\t\t<td>\n    \t\t\t\t\t\t<img [src]=\"contact.imageUrl || shadowImage\" height=\"40\" width=\"40\" class=\"img-circle img-responsive\">\n    \t\t\t\t\t</td>\n    \t\t\t\t\t<td>\n    \t\t\t\t\t\t{{ contact.firstName + ' ' + contact.lastName }}\n    \t\t\t\t\t</td>\n    \t\t\t\t</tr>\n    \t\t\t</tbody>\n    \t\t</table>\n      \t</div>\n    </div>\n  ",
            styles: ["\n\n  "],
            providers: [contact_1.ContactService, base_http_1.BaseHttpService],
            directives: [router_1.ROUTER_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [contact_1.ContactService, router_1.Router])
    ], ContactListCmp);
    return ContactListCmp;
})();
exports.ContactListCmp = ContactListCmp;
