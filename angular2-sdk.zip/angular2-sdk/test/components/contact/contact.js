var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('angular2/core');
var router_1 = require('angular2/router');
var common_1 = require('angular2/common');
var http_1 = require('angular2/http');
var contact_1 = require('../../models/contact');
var contact_group_1 = require('../../models/contact-group');
var contact_2 = require('../../services/contact');
var contact_group_2 = require('../../services/contact-group');
var group_1 = require('../../services/group');
var base_http_1 = require('../../services/base-http');
var constants = require('../../config/constants');
var contact_info_list_1 = require('../contact-info/contact-info-list');
var ContactCmp = (function () {
    function ContactCmp(contactService, groupService, contactGroupService, router, params, formBuilder, httpService) {
        this.contactService = contactService;
        this.groupService = groupService;
        this.contactGroupService = contactGroupService;
        this.router = router;
        this.params = params;
        this.formBuilder = formBuilder;
        this.httpService = httpService;
        this.id = new common_1.Control('');
        this.firstName = new common_1.Control('', common_1.Validators.required);
        this.lastName = new common_1.Control('', common_1.Validators.required);
        this.imageUrl = new common_1.Control('');
        this.skype = new common_1.Control('');
        this.twitter = new common_1.Control('');
        this.selectedGroupId = null;
        this.contact = new contact_1.Contact();
        this.contactGroups = [];
        this.remainingGroups = [];
        var contactId = params.get('id');
        if (contactId) {
            var self_1 = this;
            var contactGroupParams = new http_1.URLSearchParams();
            contactGroupParams.set('filter', 'contact_id=' + contactId);
            contactService
                .get(contactId)
                .subscribe(function (contact) { return self_1.contact = contact; });
            contactGroupService
                .query(contactGroupParams, false, true)
                .subscribe(function (contactGroups) {
                self_1.contactGroups = contactGroups;
                self_1.getRemainingGroups();
            });
        }
        this.form = this.formBuilder.group({
            firstName: this.firstName,
            lastName: this.lastName,
            imageUrl: this.imageUrl,
            skype: this.skype,
            twitter: this.twitter
        });
    }
    ContactCmp.prototype.getRemainingGroups = function () {
        var self = this;
        this.groupService
            .query()
            .subscribe(function (groups) {
            self.remainingGroups = groups.filter(function (item) {
                return !self.contactGroups.some(function (a) {
                    return a.group.id == item.id;
                });
            });
        });
    };
    ContactCmp.prototype.back = function () {
        this.router.navigate(['/ContactList']);
    };
    ;
    ContactCmp.prototype.addSelectedGroup = function () {
        if (!this.selectedGroupId)
            return;
        var self = this;
        var group = this.remainingGroups.filter(function (item) {
            return item.id == self.selectedGroupId;
        })[0];
        this.contactGroupService.addGroup(group.id, this.contact.id)
            .subscribe(function (response) {
            var newContactGroup = new contact_group_1.ContactGroup(response.id);
            newContactGroup.group = group;
            self.remainingGroups = self.remainingGroups.filter(function (item) {
                return item.id !== group.id;
            });
            self.contactGroups.push(newContactGroup);
            self.selectedGroupId = null;
        });
    };
    ;
    ContactCmp.prototype.removeGroup = function (contactGroup) {
        var self = this;
        this.contactGroupService
            .remove(contactGroup.id)
            .subscribe(function (item) {
            self.contactGroups = self.contactGroups.filter(function (item) {
                return item.id !== contactGroup.id;
            });
            self.remainingGroups.push(contactGroup.group);
        });
    };
    ContactCmp.prototype.save = function () {
        if (this.contact.id) {
            this.httpService.http.put(constants.DSP_INSTANCE_URL + '/api/v2/db/_table/contact/' + this.contact.id, this.contact.toJson(true))
                .subscribe(function (data) {
                console.log('data saved');
            });
        }
        else {
            this.httpService.http.post(constants.DSP_INSTANCE_URL + '/api/v2/db/_table/contact/', this.contact.toJson(true))
                .subscribe(function (data) {
                console.log('data saved');
            });
        }
    };
    ContactCmp = __decorate([
        core_1.Component({
            selector: 'contact',
            template: "\n    <div class=\"panel panel-default\">\n      <div class=\"panel-heading text-center\">\n        <h3 *ngIf=\"!contact.id\">Detail - New contact</h3>\n        <h3 *ngIf=\"contact.id\">Detail - {{ contact.firstName }} {{ contact.lastName }}</h3>\n      </div>\n      <div class=\"panel-body\">\n        <form class=\"form-horizontal\" [ngFormModel]=\"form\" (ngSubmit)=\"save()\">\n          <div class=\"form-group\">\n            <label for=\"firstName\" class=\"col-sm-2 control-label\">First name</label>\n            <div class=\"col-sm-10\">\n              <input class=\"form-control\" ngControl=\"firstName\" [(ngModel)]=\"contact.firstName\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <label for=\"lastName\" class=\"col-sm-2 control-label\">Last name</label>\n            <div class=\"col-sm-10\">\n              <input class=\"form-control\" ngControl=\"lastName\" [(ngModel)]=\"contact.lastName\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <label for=\"imageUrl\" class=\"col-sm-2 control-label\">Image URL</label>\n            <div class=\"col-sm-10\">\n              <input class=\"form-control\" ngControl=\"imageUrl\" [(ngModel)]=\"contact.imageUrl\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <label for=\"skype\" class=\"col-sm-2 control-label\">Skype</label>\n            <div class=\"col-sm-10\">\n              <input class=\"form-control\" ngControl=\"skype\" [(ngModel)]=\"contact.skype\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <label for=\"twitter\" class=\"col-sm-2 control-label\">Twitter</label>\n            <div class=\"col-sm-10\">\n              <input class=\"form-control\" ngControl=\"twitter\" [(ngModel)]=\"contact.twitter\">\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <label for=\"notes\" class=\"col-sm-2 control-label\">Notes</label>\n            <div class=\"col-sm-10\">\n              <textarea class=\"form-control\" [(ngModel)]=\"contact.notes\"></textarea>\n            </div>\n          </div>\n\n          <div class=\"text-center\">\n            <button type=\"submit\" class=\"btn btn-primary\">Save</button>\n            <button type=\"button\" class=\"btn btn-danger\" (click)=\"back()\">Back</button>\n          </div>\n\n        </form>\n      </div>\n    </div>\n\n\n    <div class=\"panel panel-default\" *ngIf=\"contact.id\">\n      <div class=\"panel-heading text-center\">\n        <h3>Groups</h3>\n      </div>\n      <div class=\"panel-body\">\n        <table class=\"table\">\n          <tr>\n            <td>\n              <select class=\"form-control\" [(ngModel)]=\"selectedGroupId\" placeholder=\"Select group\">\n                <option *ngFor=\"#group of remainingGroups\" [value]=\"group.id\">\n                  {{ group.name }}\n                </option>\n              </select>\n            </td>\n            <td>\n              <button type=\"button\" class=\"fa fa-plus btn btn-primary pull-right\" (click)=\"addSelectedGroup()\" (disabled)=\"!selectedGroupId\">\n              </button>\n            </td>\n          </tr>\n          <tr *ngFor=\"#contactGroup of contactGroups\">\n            <td>{{ contactGroup.group.name }}</td>\n            <td>            \n              <button type=\"button\" class=\"fa fa-trash btn btn-danger pull-right\" (click)=\"remove(contactGroup)\">\n              </button>\n            </td>\n          </tr>\n        </table>\n      </div>\n    </div>\n\n\n    <div *ngIf=\"contact.id\">\n      <contact-info-list></contact-info-list>\n    </div>\n  ",
            styles: ["\n\n  "],
            providers: [contact_2.ContactService, base_http_1.BaseHttpService, contact_group_2.ContactGroupService, group_1.GroupService],
            directives: [common_1.FORM_DIRECTIVES, contact_info_list_1.ContactInfoListCmp]
        }), 
        __metadata('design:paramtypes', [contact_2.ContactService, group_1.GroupService, contact_group_2.ContactGroupService, router_1.Router, router_1.RouteParams, common_1.FormBuilder, base_http_1.BaseHttpService])
    ], ContactCmp);
    return ContactCmp;
})();
exports.ContactCmp = ContactCmp;
