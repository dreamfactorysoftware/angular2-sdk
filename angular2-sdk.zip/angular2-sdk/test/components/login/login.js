var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
var router_1 = require('angular2/router');
var base_http_1 = require('../../services/base-http');
var constants = require('../../config/constants');
var LoginCmp = (function () {
    function LoginCmp(formBuilder, httpService, _router) {
        this.httpService = httpService;
        this._router = _router;
        this.email = new common_1.Control('', common_1.Validators.required);
        this.password = new common_1.Control('', common_1.Validators.required);
        this.form = formBuilder.group({
            email: this.email,
            password: this.password
        });
    }
    LoginCmp.prototype.storeToken = function (data) {
        this.httpService.http._defaultOptions.headers.set('X-Dreamfactory-Session-Token', data && data.session_token);
        localStorage.setItem('session_token', data.session_token);
        this._router.navigate(['ContactList']);
    };
    LoginCmp.prototype.formSubmit = function () {
        var _this = this;
        this.httpService.http.post(constants.DSP_INSTANCE_URL + '/api/v2/user/session', JSON.stringify(this.form.value))
            .subscribe(function (data) {
            _this.storeToken(data.json());
        }, function (error) {
            alert('Error, cannot login. Try again');
        });
    };
    LoginCmp = __decorate([
        core_1.Component({
            selector: 'df-login',
            template: "\n    <div class=\"signin-card\">\n\n      <h1 class=\"text-center\">Dreamfactory - Addressbook 2.0</h1>\n      <form class=\"form-horizontal\" [ngFormModel]=\"form\" (ngSubmit)=\"formSubmit()\">\n        <div class=\"form-group\">\n          <label class=\"col-sm-2 control-label\" for=\"email\">Username</label>\n          <div class=\"col-sm-10\">\n            <input class=\"form-control\" ngControl=\"email\" name=\"email\">\n          </div>\n        </div>\n\n        <div class=\"form-group\">\n          <label class=\"col-sm-2 control-label\" for=\"password\">Password</label>\n          <div class=\"col-sm-10\">\n            <input class=\"form-control\" type=\"password\" ngControl=\"password\" name=\"password\">\n          </div>\n        </div>\n\n        <div class=\"text-center\">\n          <button type=\"submit\" class=\"btn btn-success\">Submit</button>\n          <a class=\"btn btn-primary\" [routerLink]=\"['/Register']\">Register</a>\n        </div>\n\n      </form>\n    </div>\n  ",
            styles: ["\n\n  "],
            directives: [common_1.FORM_DIRECTIVES, router_1.ROUTER_DIRECTIVES],
            providers: [base_http_1.BaseHttpService]
        }), 
        __metadata('design:paramtypes', [common_1.FormBuilder, base_http_1.BaseHttpService, router_1.Router])
    ], LoginCmp);
    return LoginCmp;
})();
exports.LoginCmp = LoginCmp;
