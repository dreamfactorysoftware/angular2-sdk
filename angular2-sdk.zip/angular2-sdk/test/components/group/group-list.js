var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('angular2/core');
var router_1 = require('angular2/router');
var group_1 = require('../../services/group');
var contact_1 = require('../../services/contact');
var base_http_1 = require('../../services/base-http');
var GroupListCmp = (function () {
    function GroupListCmp(groupService, router) {
        this.groupService = groupService;
        this.router = router;
        this.groups = [];
        this.shadowImage = 'https://image.freepik.com/free-icon/male-user-shadow_318-34042.png';
        this.getList();
    }
    GroupListCmp.prototype.getList = function () {
        var self = this;
        this.groupService.query()
            .subscribe(function (groups) {
            self.groups = groups;
        });
    };
    GroupListCmp.prototype.show = function (groupId) {
        this.router.navigate(['/Group', { id: groupId }]);
    };
    GroupListCmp = __decorate([
        core_1.Component({
            selector: 'group-list',
            template: "\n   <div class=\"panel panel-default\">\n     \t<div class=\"panel-heading\">\n       \t<h3 class=\"text-center\">\n       \t\tGroups\n       \t\t<a class=\"fa fa-plus btn btn-primary pull-right\" [routerLink]=\"['/NewGroup']\"></a>\n       \t</h3>\n     \t</div>\n     \t<div class=\"panel-body\">\n       \t<table class=\"table table-hover\">\n   \t\t\t<thead>\n   \t\t\t\t<tr>\n   \t\t\t\t\t<th>\n   \t\t\t\t\t\tID\n   \t\t\t\t\t</th>\n   \t\t\t\t\t<th>\n   \t\t\t\t\t\tName\n   \t\t\t\t\t</th>\n   \t\t\t\t</tr>\n   \t\t\t</thead>\n\n   \t\t\t<tbody>\n   \t\t\t\t<tr *ngFor=\"#group of groups\" (click)=\"show(group.id)\">\n   \t\t\t\t\t<td>\n   \t\t\t\t\t\t{{ group.id }}\n   \t\t\t\t\t</td>\n   \t\t\t\t\t<td>\n   \t\t\t\t\t\t{{ group.name }}\n   \t\t\t\t\t</td>\n   \t\t\t\t</tr>\n   \t\t\t</tbody>\n   \t\t</table>\n     \t</div>\n   </div>\n\t",
            styles: ["\n\n\t"],
            providers: [group_1.GroupService, base_http_1.BaseHttpService, contact_1.ContactService],
            directives: [router_1.ROUTER_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [group_1.GroupService, router_1.Router])
    ], GroupListCmp);
    return GroupListCmp;
})();
exports.GroupListCmp = GroupListCmp;
