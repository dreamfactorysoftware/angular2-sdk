var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('angular2/core');
var router_1 = require('angular2/router');
var common_1 = require('angular2/common');
var contact_info_1 = require('../../models/contact-info');
var contact_info_2 = require('../../services/contact-info');
var base_http_1 = require('../../services/base-http');
var constants = require('../../config/constants');
var ContactInfoCmp = (function () {
    function ContactInfoCmp(contactInfoService, router, params, formBuilder, httpService) {
        this.contactInfoService = contactInfoService;
        this.router = router;
        this.params = params;
        this.formBuilder = formBuilder;
        this.httpService = httpService;
        this.id = new common_1.Control('');
        this.address = new common_1.Control('', common_1.Validators.required);
        this.infoType = new common_1.Control('', common_1.Validators.required);
        this.city = new common_1.Control('', common_1.Validators.required);
        this.state = new common_1.Control('', common_1.Validators.required);
        this.country = new common_1.Control('', common_1.Validators.required);
        this.email = new common_1.Control('', common_1.Validators.required);
        this.phone = new common_1.Control('', common_1.Validators.required);
        this.zip = new common_1.Control('', common_1.Validators.required);
        this.infoTypes = ['home', 'work', 'mobile'];
        this.contactInfo = new contact_info_1.ContactInfo();
        var id = params.get('id');
        this.contactId = params.get('contactId');
        if (id) {
            var self_1 = this;
            contactInfoService
                .get(id)
                .subscribe(function (contactInfo) { return self_1.contactInfo = contactInfo; });
        }
        this.form = this.formBuilder.group({
            address: this.address,
            infoType: this.infoType,
            city: this.city,
            state: this.state,
            country: this.country,
            email: this.email,
            phone: this.phone,
            zip: this.zip
        });
    }
    ;
    ContactInfoCmp.prototype.save = function () {
        if (this.contactInfo.id) {
            this.httpService.http.put(constants.DSP_INSTANCE_URL + '/api/v2/db/_table/contact_info/' + this.contactInfo.id, this.contactInfo.toJson(true))
                .subscribe(function (data) {
                console.log('data saved');
            });
        }
        else {
            this.httpService.http.post(constants.DSP_INSTANCE_URL + '/api/v2/db/_table/contact_info/', this.contactInfo.toJson(true))
                .subscribe(function (data) {
                console.log('data saved');
            });
        }
    };
    ;
    ContactInfoCmp.prototype.back = function () {
        this.router.navigate(['/Contact', { id: this.contactId }]);
    };
    ;
    ContactInfoCmp = __decorate([
        core_1.Component({
            selector: 'contact-info',
            template: "\n   <h2 *ngIf=\"!contactInfo.id\" class=\"text-center\">New contactInfo info</h2>\n   <h2 *ngIf=\"contactInfo.id\" class=\"text-center\">Edit </h2>\n\n   <div>\n     <form class=\"form-horizontal\" [ngFormModel]=\"form\" (ngSubmit)=\"save()\">\n       <div class=\"form-group\">\n         <label for=\"firstName\" class=\"col-sm-2 control-label\">Info Type</label>\n         <div class=\"col-sm-10\">\n           <select class=\"form-control\" ngControl=\"infoType\" [(ngModel)]=\"contactInfo.infoType\">\n             <option *ngFor=\"#item of infoTypes\" [value]=\"item\">\n               {{ item }}\n             </option>\n           </select>\n         </div>\n       </div>\n\n       <div class=\"form-group\">\n         <label for=\"lastName\" class=\"col-sm-2 control-label\">Phone</label>\n         <div class=\"col-sm-10\">\n           <input class=\"form-control\" ngControl=\"phone\" [(ngModel)]=\"contactInfo.phone\">\n         </div>\n       </div>\n\n       <div class=\"form-group\">\n         <label for=\"imageUrl\" class=\"col-sm-2 control-label\">Email</label>\n         <div class=\"col-sm-10\">\n           <input class=\"form-control\" ngControl=\"email\" [(ngModel)]=\"contactInfo.email\">\n         </div>\n       </div>\n\n       <div class=\"form-group\">\n         <label for=\"skype\" class=\"col-sm-2 control-label\">Address</label>\n         <div class=\"col-sm-10\">\n           <input class=\"form-control\" ngControl=\"address\" [(ngModel)]=\"contactInfo.address\">\n         </div>\n       </div>\n\n       <div class=\"form-group\">\n         <label for=\"twitter\" class=\"col-sm-2 control-label\">City</label>\n         <div class=\"col-sm-10\">\n           <input class=\"form-control\" ngControl=\"city\" [(ngModel)]=\"contactInfo.city\">\n         </div>\n       </div>\n\n       <div class=\"form-group\">\n         <label for=\"notes\" class=\"col-sm-2 control-label\">State</label>\n         <div class=\"col-sm-10\">\n           <input class=\"form-control\" ngControl=\"state\" [(ngModel)]=\"contactInfo.state\">\n         </div>\n       </div>\n\n       <div class=\"form-group\">\n         <label for=\"notes\" class=\"col-sm-2 control-label\">ZIP</label>\n         <div class=\"col-sm-10\">\n           <input class=\"form-control\" ngControl=\"zip\" [(ngModel)]=\"contactInfo.zip\">\n         </div>\n       </div>\n\n       <div class=\"form-group\">\n         <label for=\"notes\" class=\"col-sm-2 control-label\">Country</label>\n         <div class=\"col-sm-10\">\n           <input class=\"form-control\" ngControl=\"country\" [(ngModel)]=\"contactInfo.country\">\n         </div>\n       </div>\n\n       <div class=\"text-center\">\n         <button type=\"submit\" class=\"btn btn-primary\">Save</button>\n         <button type=\"button\" class=\"btn btn-danger\" (click)=\"back()\">Back</button>\n       </div>\n\n     </form>\n   </div>\n\t",
            styles: ["\n\n\t"],
            providers: [contact_info_2.ContactInfoService, base_http_1.BaseHttpService],
            directives: [common_1.FORM_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [contact_info_2.ContactInfoService, router_1.Router, router_1.RouteParams, common_1.FormBuilder, base_http_1.BaseHttpService])
    ], ContactInfoCmp);
    return ContactInfoCmp;
})();
exports.ContactInfoCmp = ContactInfoCmp;
