var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('angular2/core');
var router_1 = require('angular2/router');
var about_1 = require('../about/about');
var contact_list_1 = require('../contact-list/contact-list');
var contact_1 = require('../contact/contact');
var contact_info_1 = require('../contact-info/contact-info');
var group_list_1 = require('../group/group-list');
var group_1 = require('../group/group');
var login_1 = require('../login/login');
var register_1 = require('../register/register');
var name_list_1 = require('../../services/name_list');
var AppCmp = (function () {
    function AppCmp() {
    }
    AppCmp = __decorate([
        core_1.Component({
            selector: 'app',
            viewProviders: [name_list_1.NameList],
            template: "\n    <section class=\"sample-app-content\">\n      <nav>\n        <a [routerLink]=\"['/ContactList']\">Contacts</a>\n        <a [routerLink]=\"['/GroupList']\">Groups</a>\n      </nav>\n\n      <router-outlet></router-outlet>\n    </section>\n  ",
            styles: ["\n    .sample-app-content{font-family:Verdana}.sample-app-content h1{color:#999;font-size:3em}.sample-app-content h2{color:#900;font-size:2em}.sample-app-content nav,.sample-app-content p{padding:30px}.sample-app-content li,.sample-app-content p{font-size:1.2em}.sample-app-content li{font-family:Consolas}.sample-app-content nav a{display:inline-block;margin-right:15px}.sample-app-content button,.sample-app-content input{padding:5px;font-size:1em;outline:none}.fa-edit.btn-success,.fa-plus,.fa-trash.btn-danger{min-width:35px}\n  "],
            encapsulation: core_1.ViewEncapsulation.None,
            directives: [router_1.ROUTER_DIRECTIVES]
        }),
        router_1.RouteConfig([
            { path: '/', component: contact_list_1.ContactListCmp, as: 'ContactList' },
            { path: '/contacts/new', component: contact_1.ContactCmp, as: 'NewContact' },
            { path: '/contacts/:id', component: contact_1.ContactCmp, as: 'Contact' },
            { path: '/contact-info/new/:contactId', component: contact_info_1.ContactInfoCmp, as: 'NewContactInfo' },
            { path: '/contact-info/:id/:contactId', component: contact_info_1.ContactInfoCmp, as: 'ContactInfo' },
            { path: '/groups', component: group_list_1.GroupListCmp, as: 'GroupList' },
            { path: '/groups/new', component: group_1.GroupCmp, as: 'NewGroup' },
            { path: '/groups/:id', component: group_1.GroupCmp, as: 'Group' },
            { path: '/login', component: login_1.LoginCmp, as: 'Login' },
            { path: '/register', component: register_1.RegisterCmp, as: 'Register' },
            { path: '/about', component: about_1.AboutCmp, as: 'About' }
        ]), 
        __metadata('design:paramtypes', [])
    ], AppCmp);
    return AppCmp;
})();
exports.AppCmp = AppCmp;
