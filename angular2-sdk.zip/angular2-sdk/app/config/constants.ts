export const DSP_API_KEY: string = 'f0a0ea062238b277014cd36c19997b6a8360aac6dd5059d140004ddea29ffd25';
export const DSP_INSTANCE_URL: string = '';
